For testing, we provide the directory structure. You can download the complete datasets and put thme here. 

```shell
|-- datasets/test/
    |-- ColorDN
        |-- CBSD68
        |-- Kodak24
        |-- McMaster
        |-- Urban100
    |-- GrayDN
        |-- Set12
        |-- BSD68
        |-- Urban100
    |-- SIDD
        |-- ValidationGtBlocksSrgb.mat
        |-- ValidationNoisyBlocksSrgb.mat
    |-- DND
        |-- info.mat
        |-- ValidationNoisyBlocksSrgb
            |-- 0001.mat
            |-- 0002.mat
            ：  
            |-- 0050.mat
```

