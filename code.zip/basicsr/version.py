# GENERATED VERSION FILE
# TIME: Sun Nov  3 07:29:29 2024
__version__ = '1.2.0+10018c6'
short_version = '1.2.0'
version_info = (1, 2, 0)
